var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var exphbs = require('express-handlebars');
var expressValidator = require('express-validator');
var flash = require('connect-flash');
var session = require('express-session');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var mongo = require('mongodb');
var mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

mongoose.connect('mongodb://localhost/loginapp1');
var db = mongoose.connection;

var routes = require('./routes/index');
var users = require('./routes/users');
var admin1 = require('./routes/admin1');

// User pages...
var aboutus = require('./routes/aboutus');
var jobskills = require('./routes/jobskills'); 
var courses = require('./routes/courses'); 
var profile = require('./routes/profile');

// Admin Pages...
var addjobskills = require('./routes/addjobskills');
var viewuserinfo = require('./routes/viewuserinfo');

// Init App
var app = express();

// View Engine
app.set('views', path.join(__dirname, 'views'));
app.engine('handlebars', exphbs({defaultLayout:'layout'})); //default file will be layout.handlebars
app.set('view engine', 'handlebars');

// BodyParser Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

// Set Static Folder
app.use(express.static(path.join(__dirname, 'public'))); 
//things we want to be made publicly available to user we put here, like  style sheets etc.,.

// Express Session
app.use(session({
    secret: 'secret',
    saveUninitialized: true,
    resave: true
}));

// Passport init
app.use(passport.initialize());
app.use(passport.session());

// Express Validator
//Code related with "express-validator" retrieved from Github for "middleware options"
app.use(expressValidator({
  errorFormatter: function(param, msg, value) {
      var namespace = param.split('.')
      , root    = namespace.shift()
      , formParam = root;

    while(namespace.length) {
      formParam += '[' + namespace.shift() + ']';
    }
    return {
      param : formParam,
      msg   : msg,
      value : value
    };
  }
}));

// Connect Flash
app.use(flash());

// Global Vars
//These variable contents are set for Flash messages used to display messages to the user...
app.use(function (req, res, next) {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  res.locals.user = req.user || null;
  next();
});

//Adding middleware for route files here...
app.use('/', routes);
app.use('/users', users);
app.use('/users/aboutus', aboutus);
app.use('/users/jobskills', jobskills);
app.use('/users/courses', courses);
app.use('users/profile',profile);
/*app.use('/admin1', admin1);
app.use('/admin1/addjobskills', addjobskills);
app.use('/admin1/viewuserinfo', viewuserinfo);
*/
/*
app.get('/admin1', isAdmin, function(req, res) {
  res.render('admin1'); 
});
*/
// Set Port
app.set('port', (process.env.PORT || 3000));

/*app.get('/users/aboutus' , function(req, res){


  mongoClient.connect( "mongodb://localhost:27017/skillitapp" , function(err, db) { // connect to the local Database
 res.writeHead(200,{"Content-Type" : "text/html"}); // write header

    res.write('<h1>How is the weather ? </h1>'); 
    if(err) { throw err; } // check if connection is ok, else err-output
    var s= 'skill set'
    db.collection("jobskills").findOne(function(err, output) {  // finds the first object/temperature
    res.write('Hello World! <br><hr> The skill set is '+ output.s); 
  res.end();

  console.log('this code is triggered');
  db.collection("jobskills").findOne(function(err, output) {
    var s= 'skill set'
    console.log('Hello World! <br><hr> The skill set is '+ output.s);
  
  db.close(); // close the Database connection
    });
  });
});
*/

app.listen(app.get('port'), function(){
	console.log('Server started on port '+app.get('port'));
});

module.exports = app;

