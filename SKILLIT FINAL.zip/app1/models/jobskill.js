var mongoose = require('mongoose');
var JobSchema = mongoose.Schema({
	skillset: {
		type: String
	}
});


var JobSkill = module.exports = mongoose.model('JobSkill', JobSchema);