var express = require('express');
var router = express.Router();
// Get jobskills page
router.get('/users/jobskills', ensureAuthenticated, function(req, res){
	res.render('/users/jobskills');
});


/*router.post('/users/jobskills', ensureAuthenticated, function(req, res){
	{
		mongoose.connect('mongodb://localhost/skillitapp/jobskills');
		var value = ("Mobile App Development");
		var doc = db.collection('jobskills').find({"job title":"Mobile App Development"},{"_id": 0,"skill set": 1}).pretty();
	}
	res.render('/users/jobskills',{
		contents : 'xyz',
		valid : false,
		names : doc
	});
});*/



function ensureAuthenticated(req, res, next){
	if(req.isAuthenticated()){
		return next();
	} else {
		//req.flash('error_msg','You are not logged in');
		res.redirect('/users/login');
	}
}

module.exports = router;