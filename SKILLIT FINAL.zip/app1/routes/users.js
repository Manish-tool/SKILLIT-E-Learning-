var express = require('express');
var router = express.Router();
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var mongoose = require('mongoose');
var db = mongoose.connection;

var User = require('../models/user');

// Register
router.get('/register', function(req, res){
	res.render('register');
});

// Login
router.get('/login', function(req, res){
	res.render('login');
});

 // About-Us
router.get('/aboutus', function(req, res){
	console.log('this is aboutus....');
	res.render('aboutus');
}); 

// Job Skills
router.get('/jobskills', function(req, res){
	res.render('jobskills');
});

//JobSkills post
router.post('/jobskills', function(req, res){

	var jskill = req.body.jobskill;
	console.log(jskill);
	//var doc = [];
	mongoose.connect('mongodb://localhost/skillitapp');
	console.log('loading skills');
	db.collection('jobskills', function(err, collection) {
			console.log('inside else');
	var doc = db.collection.findOne({'job title': {$regex: 'jskill' ,$options: 'i'}, 'skill set': {$ne : 'null'}}, {'_id':0 , 'skill set':1}).forEach(function (doc){ printjson(doc) });
    res.render('/jobskills',{
	contents : 'xyz',
	valid : false,
	names : [doc]['skill set']
	});

});
});
	

	/*res.render('/users/jobskills');*/
/*  Job skill set retrieval  
var doc = [];
	router.get('/users/jobskills', function(req, res){
		{
			var jskill = req.body.jobskill;
			mongoose.connect('mongodb://localhost/skillitapp/jobskills');
			doc = db.jobskills.find({'job title': {$regex: 'jskill' ,$options: 'i'}, 'skill set': {$ne : 'null'}}, {'_id':0 , 'skill set':1}).forEach(function (doc){ printjson(doc) });
		}
		res.render('/users/jobskills',{
			contents : 'xyz',
			valid : false,
			names : doc
		});
	});
*/
// Courses
router.get('/courses', function(req, res){
	res.render('courses');
});

// User Profile
router.get('/profile', function(req, res){
	res.render('profile');
});


// Register User
router.post('/register', function(req, res){

	var name = req.body.name;
	var email = req.body.email;
	var username = req.body.username;
	var password = req.body.password;
	var password2 = req.body.password2;

	// Validation
	req.checkBody('name', 'Name is required').notEmpty();
	req.checkBody('email', 'Email is required').notEmpty();
	req.checkBody('email', 'Email is not valid').isEmail();
	req.checkBody('username', 'Username is required').notEmpty();
	req.checkBody('password', 'Password is required').notEmpty();
	req.checkBody('password2', 'Passwords do not match').equals(req.body.password);

	


	var errors = req.validationErrors();

	if(errors){
		res.render('register',{
			errors:errors
		});
	} else {
		var newUser = new User({
			name: name,
			email:email,
			username: username,
			password: password
		});
/*
		if(newUser, User.findOne({username: req.body.username}, function(err, user){
			if(err) {
			  console.log(err);
			}
			if(user) {
				req.flash('success_msg', 'User Exists');
	
			} else {
				req.flash('success_msg', 'User doesnt Exists');
			}
		}));*/

User.createUser(newUser, function(err, user){
			if(err) throw err;
			console.log(user);		
});

		req.flash('success_msg', 'You are registered and can now login');

		res.redirect('/users/login');
	}
});

passport.use(new LocalStrategy(
  function(username, password, done) {
   User.getUserByUsername(username, function(err, user){
   	if(err) throw err;
   	if(!user){
   		return done(null, false, {message: 'Unknown User'});
   	}
   	User.comparePassword(password, user.password, function(err, isMatch){
   		if(err) throw err;
   		if(isMatch){
   			return done(null, user);
   		} else {
   			return done(null, false, {message: 'Invalid password'});
   		}
   	});
   });
  }));

passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  User.getUserById(id, function(err, user) {
    done(err, user);
  });
});

router.post('/login',
  passport.authenticate('local', {successRedirect:'/', failureRedirect:'/users/login',failureFlash: true}),
  function(req, res) {
    res.redirect('/');
	});


	
router.get('/logout', function(req, res){
	req.logout();

	req.flash('success_msg', 'You are successfully logged out of Skill-IT!');

	res.redirect('/users/login');
});

module.exports = router;
