var express = require('express');
var router = express.Router();

// Get aboutpage
var ary = ['Amit', 'Anil', 'Hari'];

router.get('/users/aboutus', ensureAuthenticated, function(req, res){
	res.render('/users/aboutus',{
	contents : 'BRSL',
	valid : false,
	names : ary
});
});

function ensureAuthenticated(req, res, next){
	if(req.isAuthenticated()){
		return next();
	} else {
		//req.flash('error_msg','You are not logged in');
		res.redirect('/users/aboutus');
	}
}

module.exports = router;