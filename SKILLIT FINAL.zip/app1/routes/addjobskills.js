var express = require('express');
var router = express.Router();

// Get addjobskills page
router.get('/admin1/addjobskills', ensureAuthenticated, function(req, res){
	res.render('/admin1/addjobskills');
});

function ensureAuthenticated(req, res, next){
	if(req.isAuthenticated()){
		return next();
	} else {
		//req.flash('error_msg','You are not logged in');
		res.redirect('/admin1/adminlogin');
	}
}
module.exports = router;